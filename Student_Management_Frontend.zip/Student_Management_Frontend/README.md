# CampusFlow – Student Management System Frontend

A ready-to-run frontend project built with HTML, CSS and vanilla JavaScript.

## Features
- Dashboard statistics and course distribution
- Add, edit and delete student records
- Search by student name, roll number or email
- Filter by course and active/inactive status
- Attendance overview
- Responsive layout
- LocalStorage persistence (records remain in the same browser)

## Run the project
1. Extract the ZIP file.
2. Open the `Student_Management_Frontend` folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.
4. Add or edit student records from the dashboard.

No npm installation or database setup is required for this frontend demo.

## Important
This is a frontend-only demonstration. Data is stored in the browser using LocalStorage, not in MongoDB. For a full-stack version, connect the JavaScript forms to Node.js/Express API endpoints and store records in MongoDB.

## Project structure
Student_Management_Frontend/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── README.md
