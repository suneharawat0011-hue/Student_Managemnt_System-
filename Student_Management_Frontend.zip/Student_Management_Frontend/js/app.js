const STORAGE_KEY = "campusflow_students_v1";
const starterStudents = [
 {id:"s1",name:"Aarav Verma",roll:"CS2026001",email:"aarav.verma@example.com",phone:"9876543210",course:"B.Tech",year:"2nd Year",status:"Active",attendance:92,created:Date.now()-5000},
 {id:"s2",name:"Diya Singh",roll:"BCA2026012",email:"diya.singh@example.com",phone:"9876543211",course:"BCA",year:"1st Year",status:"Active",attendance:88,created:Date.now()-4000},
 {id:"s3",name:"Kabir Sharma",roll:"BBA2026021",email:"kabir.sharma@example.com",phone:"9876543212",course:"BBA",year:"3rd Year",status:"Active",attendance:76,created:Date.now()-3000},
 {id:"s4",name:"Meera Gupta",roll:"MCA2026008",email:"meera.gupta@example.com",phone:"9876543213",course:"MCA",year:"2nd Year",status:"Inactive",attendance:64,created:Date.now()-2000},
 {id:"s5",name:"Rohan Patel",roll:"BSC2026017",email:"rohan.patel@example.com",phone:"9876543214",course:"B.Sc",year:"1st Year",status:"Active",attendance:95,created:Date.now()-1000}
];
let students = loadStudents();
const $ = id => document.getElementById(id);
function loadStudents(){try{const saved=localStorage.getItem(STORAGE_KEY);return saved?JSON.parse(saved):starterStudents}catch{return starterStudents}}
function saveStudents(){localStorage.setItem(STORAGE_KEY,JSON.stringify(students))}
function initials(name){return name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase()}
function escapeHTML(value=""){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function statusBadge(status){return `<span class="status-pill ${status==="Inactive"?"inactive":""}">${escapeHTML(status)}</span>`}
function studentCell(s){return `<div class="student-cell"><div class="mini-avatar">${initials(s.name)}</div><div><strong>${escapeHTML(s.name)}</strong><small>${escapeHTML(s.email)}</small></div></div>`}
function showToast(message){const t=$("toast");t.textContent=message;t.classList.add("show");clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove("show"),2600)}
function renderDashboard(){
 $("totalStudents").textContent=students.length;
 $("activeStudents").textContent=students.filter(s=>s.status==="Active").length;
 $("totalCourses").textContent=new Set(students.map(s=>s.course)).size;
 $("avgAttendance").textContent=students.length?Math.round(students.reduce((a,s)=>a+Number(s.attendance||0),0)/students.length)+"%":"0%";
 const recent=[...students].sort((a,b)=>b.created-a.created).slice(0,5);
 $("recentTable").innerHTML=recent.length?recent.map(s=>`<tr><td>${studentCell(s)}</td><td>${escapeHTML(s.roll)}</td><td>${escapeHTML(s.course)}</td><td>${statusBadge(s.status)}</td></tr>`).join(""):`<tr><td colspan="4" class="empty-state">No students yet. Add your first student.</td></tr>`;
 const counts={};students.forEach(s=>counts[s.course]=(counts[s.course]||0)+1);
 const entries=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
 $("courseDistribution").innerHTML=entries.length?entries.map(([course,count])=>`<div class="dist-row"><span>${escapeHTML(course)}</span><div class="bar"><span style="width:${students.length?count/students.length*100:0}%"></span></div><strong>${count}</strong></div>`).join(""):`<div class="empty-state">No course data available.</div>`;
}
function renderStudents(){
 const q=$("searchInput").value.trim().toLowerCase(), course=$("courseFilter").value, status=$("statusFilter").value;
 const filtered=students.filter(s=>(!q||[s.name,s.roll,s.email].some(v=>v.toLowerCase().includes(q)))&&(!course||s.course===course)&&(!status||s.status===status));
 $("studentsTable").innerHTML=filtered.length?filtered.map(s=>`<tr><td>${studentCell(s)}</td><td>${escapeHTML(s.roll)}</td><td>${escapeHTML(s.email)}</td><td>${escapeHTML(s.course)}</td><td>${escapeHTML(s.year)}</td><td>${statusBadge(s.status)}</td><td><button class="action-btn" data-edit="${s.id}">Edit</button><button class="action-btn delete" data-delete="${s.id}">Delete</button></td></tr>`).join(""):`<tr><td colspan="7" class="empty-state">No matching students found.</td></tr>`;
 $("recordCount").textContent=`Showing ${filtered.length} of ${students.length} students`;
 const courses=[...new Set(students.map(s=>s.course))].sort();
 const current=$("courseFilter").value;
 $("courseFilter").innerHTML='<option value="">All courses</option>'+courses.map(c=>`<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`).join("");
 $("courseFilter").value=current;
}
function renderAttendance(){
 $("attendanceTable").innerHTML=students.length?students.map(s=>`<tr><td>${studentCell(s)}</td><td>${escapeHTML(s.roll)}</td><td>${escapeHTML(s.course)}</td><td><span class="attendance-bar"><span class="${s.attendance<75?"low":""}" style="width:${s.attendance}%"></span></span>${s.attendance}%</td><td>${s.attendance>=75?'<span class="status-pill">Good</span>':'<span class="status-pill inactive">Needs attention</span>'}</td></tr>`).join(""):`<tr><td colspan="5" class="empty-state">No attendance records available.</td></tr>`;
}
function renderAll(){renderDashboard();renderStudents();renderAttendance()}
function openModal(student=null){
 $("studentForm").reset();$("studentId").value=student?.id||"";
 $("modalTitle").textContent=student?"Edit student":"Add new student";
 $("saveStudent").textContent=student?"Update student":"Save student";
 if(student){["name","roll","email","phone","course","year","status","attendance"].forEach(k=>$(k).value=student[k]??"")}
 $("studentModal").classList.add("show");$("name").focus();
}
function closeModal(){$("studentModal").classList.remove("show")}
function navigate(view){
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active-page"));
 $(view+"Page").classList.add("active-page");
 document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
 $("pageName").textContent=view==="dashboard"?"Dashboard":view==="students"?"Students":"Attendance";
 $("sidebar").classList.remove("open");
}
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.view)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.goto)));
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
$("addStudentBtn").addEventListener("click",()=>openModal());
$("addStudentTop").addEventListener("click",()=>openModal());
$("closeModal").addEventListener("click",closeModal);$("cancelModal").addEventListener("click",closeModal);
$("studentModal").addEventListener("click",e=>{if(e.target===$("studentModal"))closeModal()});
$("searchInput").addEventListener("input",renderStudents);
$("courseFilter").addEventListener("change",renderStudents);$("statusFilter").addEventListener("change",renderStudents);
$("studentsTable").addEventListener("click",e=>{
 const edit=e.target.closest("[data-edit]"), del=e.target.closest("[data-delete]");
 if(edit){const s=students.find(x=>x.id===edit.dataset.edit);if(s)openModal(s)}
 if(del){const s=students.find(x=>x.id===del.dataset.delete);if(s&&confirm(`Delete ${s.name}'s record? This cannot be undone.`)){students=students.filter(x=>x.id!==s.id);saveStudents();renderAll();showToast("Student record deleted.")}}
});
$("studentForm").addEventListener("submit",e=>{
 e.preventDefault();
 const id=$("studentId").value;
 const record={id:id||"s"+Date.now(),name:$("name").value.trim(),roll:$("roll").value.trim(),email:$("email").value.trim(),phone:$("phone").value.trim(),course:$("course").value,year:$("year").value,status:$("status").value,attendance:Number($("attendance").value||0),created:id?(students.find(s=>s.id===id)?.created||Date.now()):Date.now()};
 if(students.some(s=>s.roll.toLowerCase()===record.roll.toLowerCase()&&s.id!==id)){showToast("That roll number is already registered.");$("roll").focus();return}
 if(students.some(s=>s.email.toLowerCase()===record.email.toLowerCase()&&s.id!==id)){showToast("That email address is already registered.");$("email").focus();return}
 if(id){students=students.map(s=>s.id===id?record:s);showToast("Student details updated successfully.")}
 else{students.push(record);showToast("New student added successfully.")}
 saveStudents();renderAll();closeModal();
});
$("todayLabel").textContent=new Intl.DateTimeFormat("en-IN",{weekday:"short",day:"numeric",month:"short",year:"numeric"}).format(new Date());
renderAll();
